#include <iostream>
#include "Calculator.h"
using std::cout;
using std::endl;

int main() {
    int result = add(4,5);
    cout << "Result: " << result << endl;

}
